
import './App.css'
import Aluno from './components/Aluno'
import InfoCurso from './components/InfoCurso'
import Mensagem from './components/Mensagem'

function App() {
 

  return (
    //HTML
    <>
    <h1>Lucky</h1>


    <Mensagem />
    <InfoCurso />
    <Aluno></Aluno>

    </>
  )
}

export default App
