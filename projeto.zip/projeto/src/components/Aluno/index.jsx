import '.style.css'

export default function Aluno(){
    
    return(
        <div className='aluno'>
            <h2>Dados do Aluno</h2>
            <p><strong>Nome:</strong>Lucas s</p>
            <p><strong>Email:</strong>lucasantls19@gmail.com</p>
            <p><strong>CPF:</strong>06679530512</p>
        </div>
    )
}