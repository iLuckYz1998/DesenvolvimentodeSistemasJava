import './style.css'

export default function Mensagem(){
    return(
        <div className='mensagem'>
            <p>Seja bem-vindo(a) ao nosso site!</p>
        </div>
    )


}