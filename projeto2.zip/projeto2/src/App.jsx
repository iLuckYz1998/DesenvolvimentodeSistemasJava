import './App.css'
import AdicionarAluno from './components/AdicionarAluno'
import Footer from './components/Footer'
import Header from './components/Header'

function App() {

  return (
    <>
      <Header/>
      <h1>SENAI</h1>
      <AdicionarAluno/>
      <Footer/>
    </>
  )
}

export default App
