import './style.css'

export default function Header() {
    return (
        <header>
            <div>Sistema Escolar</div>
        </header>
    )

}

    

